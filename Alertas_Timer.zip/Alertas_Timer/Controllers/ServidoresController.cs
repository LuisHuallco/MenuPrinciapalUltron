﻿using Alertas_Timer.Data;
using Alertas_Timer.DATA;
using Alertas_Timer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Alertas_Timer.Controllers
{
    public static class ServidoresController
    {
        private static TimerDbContext _context = new TimerDbContext();

        public static List<ServidorModel> ObtenerTodos()
        {
            return _context.Servidores.ToList();
        }

        public static ServidorModel ObtenerPorId(int id)
        {
            return _context.Servidores.Find(id);
        }

        public static string Insertar(ServidorModel servidor)
        {
            try
            {
                _context.Servidores.Add(servidor);
                _context.SaveChanges();
                return "ok";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message);
                return "error";
            }
        }

        public static string Editar(ServidorModel servidor)
        {
            try
            {
                var actual = _context.Servidores.Find(servidor.Id);
                if (actual != null)
                {
                    actual.nombre_servidor = servidor.nombre_servidor;
                    actual.ip = servidor.ip;
                    actual.ubicacion = servidor.ubicacion;
                    actual.sistema_operativo = servidor.sistema_operativo;
                    actual.estado = servidor.estado;
                    _context.SaveChanges();
                    return "ok";
                }
                return "error";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al editar: " + ex.Message);
                return "error";
            }
        }

        public static string Eliminar(int id)
        {
            try
            {
                var servidor = _context.Servidores.Find(id);
                if (servidor != null)
                {
                    _context.Servidores.Remove(servidor);
                    _context.SaveChanges();
                    return "ok";
                }
                return "error";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar: " + ex.Message);
                return "error";
            }
        }
    }
}
