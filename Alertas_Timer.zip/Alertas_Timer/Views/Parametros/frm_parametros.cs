﻿using Alertas_Timer.DATA;
using Alertas_Timer.Models;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace Alertas_Timer.Views.Parametros
{
    public partial class frm_parametros : Form
    {
        private int idSeleccionado = 0;

        public frm_parametros()
        {
            InitializeComponent();
            dgvParametros.AllowUserToAddRows = false;
            dgvParametros.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void frm_parametros_Load(object sender, EventArgs e)
        {
            cargarParametros();
        }

        private void cargarParametros()
        {
            using (var context = new TimerDbContext())
            {
                dgvParametros.DataSource = context.Parametros.ToList();
                dgvParametros.Columns["Id"].Visible = false;
            }
        }

        private void dgvParametros_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                idSeleccionado = Convert.ToInt32(dgvParametros.Rows[e.RowIndex].Cells["Id"].Value);
                txtNombreParametro.Text = dgvParametros.Rows[e.RowIndex].Cells["nombre_parametro"].Value.ToString();
                txtUnidad.Text = dgvParametros.Rows[e.RowIndex].Cells["unidad"].Value.ToString();
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombreParametro.Text) || string.IsNullOrWhiteSpace(txtUnidad.Text))
            {
                MessageBox.Show("Por favor, complete todos los campos antes de guardar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var context = new TimerDbContext())
            {
                var nuevo = new ParametroModel
                {
                    nombre_parametro = txtNombreParametro.Text.Trim(),
                    unidad = txtUnidad.Text.Trim()
                };
                context.Parametros.Add(nuevo);
                context.SaveChanges();
            }

            limpiar();
            cargarParametros();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado > 0)
            {
                using (var context = new TimerDbContext())
                {
                    var parametro = context.Parametros.Find(idSeleccionado);
                    if (parametro != null)
                    {
                        parametro.nombre_parametro = txtNombreParametro.Text.Trim();
                        parametro.unidad = txtUnidad.Text.Trim();
                        context.SaveChanges();
                    }
                }

                limpiar();
                cargarParametros();
            }
            else
            {
                MessageBox.Show("Seleccione una fila para editar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado > 0)
            {
                var confirm = MessageBox.Show("¿Está seguro de eliminar este parámetro?", "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    using (var context = new TimerDbContext())
                    {
                        var parametro = context.Parametros.Find(idSeleccionado);
                        if (parametro != null)
                        {
                            context.Parametros.Remove(parametro);
                            context.SaveChanges();
                        }
                    }

                    limpiar();
                    cargarParametros();
                }
            }
            else
            {
                MessageBox.Show("Seleccione una fila para eliminar.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            limpiar();
            this.Close();
        }

        private void limpiar()
        {
            txtNombreParametro.Clear();
            txtUnidad.Clear();
            idSeleccionado = 0;
            dgvParametros.ClearSelection();
        }
    }
}
