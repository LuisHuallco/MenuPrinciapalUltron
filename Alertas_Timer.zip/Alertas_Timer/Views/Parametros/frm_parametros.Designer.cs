﻿namespace Alertas_Timer.Views.Parametros
{
    partial class frm_parametros
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            btnGuardar = new Button();
            btnEliminar = new Button();
            btnEditar = new Button();
            btnCancelar = new Button();
            txtNombreParametro = new TextBox();
            txtUnidad = new TextBox();
            dgvParametros = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvParametros).BeginInit();
            SuspendLayout();
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(85, 411);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(144, 52);
            btnGuardar.TabIndex = 0;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(252, 411);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(144, 52);
            btnEliminar.TabIndex = 1;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(422, 411);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(144, 52);
            btnEditar.TabIndex = 2;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(595, 411);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(144, 52);
            btnCancelar.TabIndex = 3;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // txtNombreParametro
            // 
            txtNombreParametro.Location = new Point(40, 179);
            txtNombreParametro.Name = "txtNombreParametro";
            txtNombreParametro.Size = new Size(296, 39);
            txtNombreParametro.TabIndex = 4;
            // 
            // txtUnidad
            // 
            txtUnidad.Location = new Point(40, 259);
            txtUnidad.Name = "txtUnidad";
            txtUnidad.Size = new Size(296, 39);
            txtUnidad.TabIndex = 5;
            // 
            // dgvParametros
            // 
            dgvParametros.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvParametros.Location = new Point(360, 98);
            dgvParametros.Name = "dgvParametros";
            dgvParametros.RowHeadersWidth = 51;
            dgvParametros.Size = new Size(439, 287);
            dgvParametros.TabIndex = 6;
            dgvParametros.CellClick += dgvParametros_CellClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(40, 224);
            label1.Name = "label1";
            label1.Size = new Size(95, 32);
            label1.TabIndex = 7;
            label1.Text = "Unidad:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(40, 147);
            label2.Name = "label2";
            label2.Size = new Size(127, 32);
            label2.TabIndex = 8;
            label2.Text = "Parametro:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(269, 37);
            label3.Name = "label3";
            label3.Size = new Size(255, 31);
            label3.TabIndex = 9;
            label3.Text = "Gestion de Parametros";
            // 
            // frm_parametros
            // 
            AutoScaleDimensions = new SizeF(13F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(811, 498);
            Controls.Add(label3);
            Controls.Add(dgvParametros);
            Controls.Add(txtUnidad);
            Controls.Add(txtNombreParametro);
            Controls.Add(btnCancelar);
            Controls.Add(btnEditar);
            Controls.Add(btnEliminar);
            Controls.Add(btnGuardar);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(5);
            Name = "frm_parametros";
            Text = "frm_parametros";
            Load += frm_parametros_Load;
            ((System.ComponentModel.ISupportInitialize)dgvParametros).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnGuardar;
        private Button btnEliminar;
        private Button btnEditar;
        private Button btnCancelar;
        private TextBox txtNombreParametro;
        private TextBox txtUnidad;
        private DataGridView dgvParametros;
        private Label label1;
        private Label label2;
        private Label label3;
    }
}
