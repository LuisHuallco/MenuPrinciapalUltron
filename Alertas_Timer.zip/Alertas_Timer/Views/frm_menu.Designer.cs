﻿namespace Alertas_Timer.Views
{
    partial class frm_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_menu));
            menuStrip1 = new MenuStrip();
            alertasToolStripMenuItem = new ToolStripMenuItem();
            servidoresToolStripMenuItem = new ToolStripMenuItem();
            parametrosToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            statusStrip1 = new StatusStrip();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            toolStripStatusLabel2 = new ToolStripStatusLabel();
            picFooter = new PictureBox();
            menuStrip1.SuspendLayout();
            statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picFooter).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { alertasToolStripMenuItem, servidoresToolStripMenuItem, parametrosToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1199, 39);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // alertasToolStripMenuItem
            // 
            alertasToolStripMenuItem.Name = "alertasToolStripMenuItem";
            alertasToolStripMenuItem.Size = new Size(104, 35);
            alertasToolStripMenuItem.Text = "Alertas";
            alertasToolStripMenuItem.Click += alertasToolStripMenuItem_Click;
            // 
            // servidoresToolStripMenuItem
            // 
            servidoresToolStripMenuItem.Name = "servidoresToolStripMenuItem";
            servidoresToolStripMenuItem.Size = new Size(141, 35);
            servidoresToolStripMenuItem.Text = "Servidores";
            servidoresToolStripMenuItem.Click += servidoresToolStripMenuItem_Click;
            // 
            // parametrosToolStripMenuItem
            // 
            parametrosToolStripMenuItem.Name = "parametrosToolStripMenuItem";
            parametrosToolStripMenuItem.Size = new Size(149, 35);
            parametrosToolStripMenuItem.Text = "Parametros";
            parametrosToolStripMenuItem.Click += parametrosToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 22F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.MidnightBlue;
            label1.Location = new Point(35, 43);
            label1.Name = "label1";
            label1.Size = new Size(1132, 50);
            label1.TabIndex = 1;
            label1.Text = "Sistema de Monitoreo de Servidores con Alertas Automatizadas";
            label1.TextAlign = ContentAlignment.TopCenter;
            label1.Click += label1_Click;
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(20, 20);
            statusStrip1.Items.AddRange(new ToolStripItem[] { toolStripStatusLabel1, toolStripStatusLabel2 });
            statusStrip1.Location = new Point(0, 507);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(1199, 26);
            statusStrip1.TabIndex = 2;
            statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.DisplayStyle = ToolStripItemDisplayStyle.Text;
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(305, 20);
            toolStripStatusLabel1.Text = "Ultrón - Sistema de Monitoreo de Servidores";
            toolStripStatusLabel1.Click += toolStripStatusLabel1_Click;
            // 
            // toolStripStatusLabel2
            // 
            toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            toolStripStatusLabel2.Size = new Size(227, 20);
            toolStripStatusLabel2.Text = "- Supervisión Automatizada 24/7";
            // 
            // picFooter
            // 
            picFooter.Image = (Image)resources.GetObject("picFooter.Image");
            picFooter.Location = new Point(107, 112);
            picFooter.Name = "picFooter";
            picFooter.Size = new Size(1005, 375);
            picFooter.SizeMode = PictureBoxSizeMode.StretchImage;
            picFooter.TabIndex = 3;
            picFooter.TabStop = false;
            // 
            // frm_menu
            // 
            AutoScaleDimensions = new SizeF(13F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1199, 533);
            Controls.Add(picFooter);
            Controls.Add(statusStrip1);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            Font = new Font("Segoe UI", 14F);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(5);
            Name = "frm_menu";
            Text = "Menu Prrincipal";
            Load += frm_menu_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picFooter).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem alertasToolStripMenuItem;
        private ToolStripMenuItem servidoresToolStripMenuItem;
        private ToolStripMenuItem parametrosToolStripMenuItem;
        private Label label1;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private ToolStripStatusLabel toolStripStatusLabel2;
        private PictureBox picFooter;
    }
}