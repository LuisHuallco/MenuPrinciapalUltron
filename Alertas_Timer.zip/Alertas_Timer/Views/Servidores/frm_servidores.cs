﻿using Alertas_Timer.Controllers;
using Alertas_Timer.Models;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Alertas_Timer.Views.Servidores
{
    public partial class frm_servidores : Form
    {
        private int idSeleccionado = 0;

        public frm_servidores()
        {
            InitializeComponent();
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
        }

        private void frm_servidores_Load(object sender, EventArgs e)
        {
            cargarLista();
        }

        private void cargarLista()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = ServidoresController.ObtenerTodos();
            listBox1.DisplayMember = "nombre_servidor";
            listBox1.ValueMember = "Id";
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            var servidor = new ServidorModel
            {
                nombre_servidor = txt_nombre.Text,
                ip = txt_ip.Text,
                sistema_operativo = txt_sistema_operativo.Text,
                ubicacion = txt_ubicacion.Text,
                estado = chb_estado.Checked ? "Activo" : "Inactivo"
            };

            var resultado = ServidoresController.Insertar(servidor);
            if (resultado == "ok")
            {
                MessageBox.Show("Servidor guardado correctamente.");
                limpiar();
                cargarLista();
            }
        }

        private void btn_editar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un servidor para editar.");
                return;
            }

            var servidor = new ServidorModel
            {
                Id = idSeleccionado,
                nombre_servidor = txt_nombre.Text,
                ip = txt_ip.Text,
                sistema_operativo = txt_sistema_operativo.Text,
                ubicacion = txt_ubicacion.Text,
                estado = chb_estado.Checked ? "Activo" : "Inactivo"
            };

            var resultado = ServidoresController.Editar(servidor);
            if (resultado == "ok")
            {
                MessageBox.Show("Servidor editado.");
                limpiar();
                cargarLista();
            }
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un servidor para eliminar.");
                return;
            }

            var confirm = MessageBox.Show("¿Seguro que desea eliminar este servidor?", "Confirmar", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                var resultado = ServidoresController.Eliminar(idSeleccionado);
                if (resultado == "ok")
                {
                    MessageBox.Show("Servidor eliminado.");
                    limpiar();
                    cargarLista();
                }
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedValue is int id)
            {
                var servidor = ServidoresController.ObtenerPorId(id);
                if (servidor != null)
                {
                    idSeleccionado = servidor.Id;
                    txt_nombre.Text = servidor.nombre_servidor;
                    txt_ip.Text = servidor.ip;
                    txt_sistema_operativo.Text = servidor.sistema_operativo;
                    txt_ubicacion.Text = servidor.ubicacion;
                    chb_estado.Checked = servidor.estado == "Activo";
                }
            }
        }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {
            limpiar();
            this.Close();
        }

        private void limpiar()
        {
            txt_nombre.Clear();
            txt_ip.Clear();
            txt_sistema_operativo.Clear();
            txt_ubicacion.Clear();
            chb_estado.Checked = false;
            idSeleccionado = 0;
            listBox1.ClearSelected();
        }

        private void chb_estado_CheckedChanged(object sender, EventArgs e)
        {
            chb_estado.Text = chb_estado.Checked ? "Activo" : "Inactivo";
            chb_estado.BackColor = chb_estado.Checked ? Color.Green : Color.Red;
        }
    }
}
