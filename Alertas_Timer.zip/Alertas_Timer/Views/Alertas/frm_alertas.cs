﻿using Alertas_Timer.Controllers;
using System;
using System.Windows.Forms;

namespace Alertas_Timer.Views.Alertas
{
    public partial class frm_alertas : Form
    {
        private readonly AlertaController _alertaController;

        public frm_alertas()
        {
            InitializeComponent();
            _alertaController = new AlertaController();
        }

        private void frm_alertas_Load(object sender, EventArgs e)
        {
            timer1.Interval = 5000;
            dgvListaAlertas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void btnDetener_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            dgvListaAlertas.Columns.Clear();

            dgvListaAlertas.Columns.Add(new DataGridViewTextBoxColumn() { HeaderText = "Id", DataPropertyName = "Id" });
            dgvListaAlertas.Columns.Add(new DataGridViewTextBoxColumn() { HeaderText = "Tipo de Alerta", DataPropertyName = "tipo" });
            dgvListaAlertas.Columns.Add(new DataGridViewTextBoxColumn() { HeaderText = "Ubicación del Servidor", DataPropertyName = "ubicacion_servidor" });
            dgvListaAlertas.Columns.Add(new DataGridViewTextBoxColumn() { HeaderText = "Mensaje", DataPropertyName = "mensaje" });
            dgvListaAlertas.Columns.Add(new DataGridViewTextBoxColumn() { HeaderText = "Estado", DataPropertyName = "estado" });
            dgvListaAlertas.Columns.Add(new DataGridViewTextBoxColumn() { HeaderText = "Fecha", DataPropertyName = "fecha" });
            dgvListaAlertas.Columns.Add(new DataGridViewTextBoxColumn() { HeaderText = "Hora", DataPropertyName = "hora" });

            dgvListaAlertas.AutoGenerateColumns = false;
            dgvListaAlertas.DataSource = _alertaController.todos();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
