﻿namespace Alertas_Timer.Views.Alertas
{
    partial class frm_alertas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dgvListaAlertas = new DataGridView();
            btnIniciar = new Button();
            btnDetener = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            btnCancelar = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvListaAlertas).BeginInit();
            SuspendLayout();
            // 
            // dgvListaAlertas
            // 
            dgvListaAlertas.AllowUserToAddRows = false;
            dgvListaAlertas.AllowUserToDeleteRows = false;
            dgvListaAlertas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvListaAlertas.Location = new Point(55, 57);
            dgvListaAlertas.Name = "dgvListaAlertas";
            dgvListaAlertas.ReadOnly = true;
            dgvListaAlertas.RowHeadersWidth = 51;
            dgvListaAlertas.Size = new Size(1121, 384);
            dgvListaAlertas.TabIndex = 5;
            // 
            // btnIniciar
            // 
            btnIniciar.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btnIniciar.Location = new Point(304, 468);
            btnIniciar.Margin = new Padding(5);
            btnIniciar.Name = "btnIniciar";
            btnIniciar.Size = new Size(158, 75);
            btnIniciar.TabIndex = 4;
            btnIniciar.Text = "Iniciar";
            btnIniciar.UseVisualStyleBackColor = true;
            btnIniciar.Click += btnIniciar_Click;
            // 
            // btnDetener
            // 
            btnDetener.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btnDetener.Location = new Point(542, 468);
            btnDetener.Margin = new Padding(5);
            btnDetener.Name = "btnDetener";
            btnDetener.Size = new Size(158, 75);
            btnDetener.TabIndex = 3;
            btnDetener.Text = "Detener";
            btnDetener.UseVisualStyleBackColor = true;
            btnDetener.Click += btnDetener_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // btnCancelar
            // 
            btnCancelar.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btnCancelar.Location = new Point(771, 468);
            btnCancelar.Margin = new Padding(5);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(158, 75);
            btnCancelar.TabIndex = 6;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(542, 9);
            label1.Name = "label1";
            label1.Size = new Size(90, 31);
            label1.TabIndex = 7;
            label1.Text = "Alertas";
            // 
            // frm_alertas
            // 
            AutoScaleDimensions = new SizeF(13F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1215, 570);
            Controls.Add(label1);
            Controls.Add(btnCancelar);
            Controls.Add(dgvListaAlertas);
            Controls.Add(btnIniciar);
            Controls.Add(btnDetener);
            Font = new Font("Segoe UI", 14F);
            Margin = new Padding(5);
            Name = "frm_alertas";
            Text = "frm_alertas";
            Load += frm_alertas_Load;
            ((System.ComponentModel.ISupportInitialize)dgvListaAlertas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvListaAlertas;
        private Button btnIniciar;
        private Button btnDetener;
        private System.Windows.Forms.Timer timer1;
        private Button btnCancelar;
        private Label label1;
    }
}