﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Alertas_Timer.Models
{
    public class AlertaModel
    {
        public int Id { get; set; }
        public string tipo { get; set; }
        public float valor { get; set; }
        public DateOnly fecha { get; set; }
        public TimeOnly hora { get; set; }
        public string mensaje { get; set; }
        public string estado { get; set; }
        public ServidorModel Servidores { get; set; }
        public ParametroModel Parametros { get; set; }

        // Vistas - Servidores
        [NotMapped] 
        public int id_servidor => Servidores?.Id ?? 0;
        [NotMapped] 
        public string nombre_servidor => Servidores?.nombre_servidor ?? "";
        [NotMapped] 
        public string ip_servidor => Servidores?.ip ?? "";
        [NotMapped] 
        public string ubicacion_servidor => Servidores?.ubicacion ?? "";
        [NotMapped] 
        public string sistema_operativo => Servidores?.sistema_operativo ?? "";
        [NotMapped] 
        public string estado_servidor => Servidores?.estado ?? "";

        // Vistas - Parámetros
        [NotMapped] 
        public int id_parametros => Parametros?.Id ?? 0;
        [NotMapped] 
        public string nombre_parametro => Parametros?.nombre_parametro ?? "";
        [NotMapped] 
        public string unidad_parametros => Parametros?.unidad ?? "";

        // ✅ Solución para mostrar la hora en el DataGridView
        [NotMapped] 
        public string hora_string => hora.ToString("HH:mm:ss");
    }
}
