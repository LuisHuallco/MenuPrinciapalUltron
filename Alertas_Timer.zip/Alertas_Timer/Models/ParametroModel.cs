﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Alertas_Timer.Models
{
    public class ParametroModel
    {
        public int Id { get; set; }
        public string nombre_parametro { get; set; }
        public string unidad { get; set; }
    }
}
